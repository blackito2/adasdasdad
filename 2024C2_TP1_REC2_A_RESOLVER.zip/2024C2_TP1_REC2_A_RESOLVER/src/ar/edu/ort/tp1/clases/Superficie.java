package ar.edu.ort.tp1.clases;

public enum Superficie {
	CEMENTO, SINTÉTICO, CESPED_ARTIFICAL; 
}
