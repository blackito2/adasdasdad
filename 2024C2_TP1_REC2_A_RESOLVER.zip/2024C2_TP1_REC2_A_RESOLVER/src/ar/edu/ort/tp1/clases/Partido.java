package ar.edu.ort.tp1.clases;

public class Partido {
	

	
}
