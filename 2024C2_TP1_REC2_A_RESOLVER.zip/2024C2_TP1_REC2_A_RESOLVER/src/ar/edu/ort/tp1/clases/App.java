package ar.edu.ort.tp1.clases;

public class App {
	
	

	public App() {
		
	}
	
	
	
	public void informarRanking() {
		
	}
	
	
	
	private void actualizarRanking() {
		//En este caso se establece el primer 
		//puesto del ranking por cada categoría
		
		
	}

	
	
	private boolean buscarIntegrante(Integrante integrante) {
		
		return false; 
	}
}
