package ar.edu.ort.tp1.clases;

public interface Resultable {
	public void conformarResultado();
}
