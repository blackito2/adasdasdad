package ar.edu.ort.tp1.clases;

public enum Pala {
	REDONDA, LAGRIMA, DIAMANTE; 
}
