package ar.edu.ort.tp1.clases;

public enum Posicion {
	DRIVE, REVES, AMBAS; 
}
