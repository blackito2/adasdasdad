package ar.edu.ort.tp1.clases;

public enum Pared {
	BLINDEX, MURO;
}
